# scplot <img src='man/figures/logo.png' align="right" height = "135" />

Add on package for scan for scdf plots based on ggplot2.

Install with:

`devtools::install_github("jazznbass/scplot", dependencies = TRUE)`

Make sure you have **Rtools** (https://cran.r-project.org/bin/windows/Rtools/) installed when you are working on a Windows OS.

The package is in an experimental stage.


