## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(warning = FALSE, message = FALSE)
library(scplot)

## ----eval=FALSE---------------------------------------------------------------
#  scplot(exampleABC) %>%
#    add_title("My plot") %>%
#    add_caption("Note: A nice plot")

## -----------------------------------------------------------------------------
scplot(exampleAB)

## -----------------------------------------------------------------------------
scplot(exampleAB_add) %>%
  add_dataline("depression")

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_statline("mean", color = "darkred") %>%
  add_statline("max", color = "darkblue", linetype = "dashed") %>%
  add_statline("min", color = "brown", linetype = "dashed")

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_statline("mean", phase = "A", color = "darkred") %>%
  add_statline("max", phase = c("B", "C"), color = "darkblue", linetype = "dashed") %>%
  add_statline("min", phase = c(2, 3), color = "orange", linetype = "dashed")

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_statline("trend", color = "darkred") %>%
  add_statline("trendA", color = "darkblue", linetype = "dashed")

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_statline("loess", color = "darkred") %>%
  add_statline("movingMean", color = "darkblue")

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_statline("movingMean", lag = 1, color = "darkblue") %>%
  add_statline("quantile", probs = 0.75, color = "darkred")

## -----------------------------------------------------------------------------
scplot(exampleAB_add) %>%
  add_dataline("cigarrets") %>%
  add_statline("mean", variable = "cigarrets", color = "darkred") %>%
  add_statline("trend", linetype = "dashed")

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_marks(case = 1, positions = c(7, 12)) %>%
  add_marks(case = 3, positions = c(3, 17), color = "blue", size = 7)

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_marks(case = 1, positions = "mt > 15") %>%
  add_marks(case = 2, positions = 'phase == "B"', color = "green", size = 5) %>%
  add_marks(case = 3, positions = "values > quantile(values, probs = 0.80)", color = "blue", size = 7) %>%
  add_marks(case = "all", positions = "values < quantile(values, probs = 0.20)", color = "yellow", size = 7) %>%
  add_caption("Note.
red: mt > 15 in case 1; 
green: phase 'B' in case 2; 
blue: values > 80% quantile of case 3; 
yellow: values < 20% quantile of all cases")

## -----------------------------------------------------------------------------
scplot(exampleABC_outlier) %>% 
  add_marks(positions = outlier(exampleABC_outlier), size = 3)

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_text("Here!", case = 2, x = 10, y = 80, color = "red")

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_arrow(case = 1, x0 = 6, y0 = 90, x1 = 3, y1 = 63) %>%
  add_text("Problem", case = 1, x = 6, y = 94, color = "red", size = 1, hjust = 0 ) 

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  set_dataline(colour = "blue", size = 1, linetype = "dotted", 
               point = list(colour = "red", size = 1, shape = 2) )

# Equivalent_
# scplot(exampleABC) %>%
#   set_dataline(line = list(colour = "blue", size = 1, linetype = "dotted"), 
#                point = list(colour = "red", size = 1, shape = 2)) 


## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  set_background(fill = "grey90", color = "black", size = 2)

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  set_panel(fill = "tan1", color = "palevioletred", size = 2)

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  set_panel(fill = c("grey80", "white", "blue4"))

## ----results='asis', echo=FALSE-----------------------------------------------
themes <- paste0("`", names(scplot:::.scplot_themes), "`")
cat(paste0(themes, collapse = ", "))

## -----------------------------------------------------------------------------
scplot(exampleABC)

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_theme("basic")

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_theme("minimal")

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_theme("dark")

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_theme("sienna")

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_theme("sienna", "minimal", "small")

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_theme("small", "minimal", "sienna")

## -----------------------------------------------------------------------------
scplot(exampleAB_decreasing$Peter) %>%
  set_base_text(colour = "blue", family = "serif", face = "italic", size = 14)

## -----------------------------------------------------------------------------
scplot(exampleAB_decreasing) %>%
  add_title("A new plot", color = "darkblue", size = 1.3) %>%
  add_caption("Note. What a nice plot!", face = "italic", colour = "darkred")

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_statline("mean", color = "darkred") %>%
  add_statline("min", phase = "B", size = 0.2, color = "darkblue") %>%
  add_legend()

## -----------------------------------------------------------------------------
scplot(exampleABC) %>%
  add_statline("mean", color = "darkred") %>%
  add_legend(
    position = "left", 
    title = list(size = 12, face = "italic"),
    background = list(fill = "grey95", colour = "black")
  )

## -----------------------------------------------------------------------------
scplot(exampleA1B1A2B2) %>% 
  set_xaxis(increment_from = 0, increment = 5, 
            color = "darkred", size = 0.7, angle = -90) %>%
  set_yaxis(limits = c(0, 50), size = 0.7, color = "darkred") 

## -----------------------------------------------------------------------------
scplot(exampleA1B1A2B2) %>% 
  set_ylabel("Score", color = "darkred", angle = 0) %>%
  set_xlabel("Session", color = "darkred")

## -----------------------------------------------------------------------------
scplot(exampleA1B1A2B2) %>%
  set_casenames(c("A", "B", "C"), color = "darkblue", size = 1)

## -----------------------------------------------------------------------------
scplot(exampleA1B1A2B2) %>%
  set_casenames(position = "strip", 
                background = list(fill = "lightblue"))

## -----------------------------------------------------------------------------
scplot(exampleABC) %>% 
  add_labels(text = list(color = "black", size = 0.7), 
             background = list(fill = "grey98"), nudge_y = 7)
 

## -----------------------------------------------------------------------------
scplot(exampleABC) %>% 
  add_labels(text = list(color = "black", size = 0.7), 
             background = list(fill = "grey98"), nudge_y = 0)
 

## -----------------------------------------------------------------------------
scplot(exampleAB_mpd) %>% 
  add_ridge("grey50")

## -----------------------------------------------------------------------------

p1 <- scplot(byHeart2011$`Lisa (Turkish)`) %>% 
        add_theme("minimal") %>%
        as_ggplot()
p2 <- scplot(byHeart2011$`Patrick (Spanish)`) %>% 
        add_theme("minimal") %>% 
        as_ggplot()
p3 <- scplot(byHeart2011$`Anna (Twi)`) %>% 
        add_theme("minimal") %>% 
        as_ggplot()
p4 <- scplot(byHeart2011$`Melanie (Swedish)`) %>% 
        add_theme("minimal") %>% 
        as_ggplot()

library(patchwork)
p1 + p2 + p3 + p4 + plot_annotation(tag_levels = "a", tag_suffix =  ")")


## -----------------------------------------------------------------------------
scplot(example_A24) %>% 
  add_theme("default") %>%
  add_statline("lowess", color = "darkred", size = 1.5) %>%
  add_statline("loess", color = "red", size = 1.5) %>%
  add_statline("movingMean", lag = 3, color = "lightpink", size = 1.5) %>%
  set_xaxis(size = 0.8, angle = 35) %>%
  set_dataline(point = "none") %>%
  add_legend(position = c(0.8, 0.75), background = list(color = "grey50")) %>%
  set_phasenames(c("no speedlimit", "with speedlimit"), position = "left", 
                 hjust = 0, vjust = 1) %>%
  set_casenames("") %>%
  add_title("Effect of a speedlimit on the A24") %>%
  add_caption("Note: Moving mean calculated with lag three", face = 3) %>%
  add_ridge(color = "lightblue")
  

## ----multi-variables----------------------------------------------------------
scplot(exampleAB_add) %>%
  add_dataline("cigarrets", point = list(size = 1)) %>%
  add_statline("trend", linetype = "dashed") %>%
  add_statline("mean", variable = "cigarrets", color = "darkred") %>%
  add_marks(positions = c(14,20), size = 3, variable = "cigarrets")%>%
  add_marks(positions = "cigarrets > quantile(cigarrets, 0.75)", size = 3) %>%
  set_xaxis(increment = 5) %>%
  set_phasenames(color = NA) %>%
  set_casenames(position = "strip") %>%
  add_legend(
    section_labels = c("", ""),
    labels = c(NA, NA, "Trend of wellbeing", "Mean of cigarrets"),
    text = list(face = 3)
  ) %>%
  set_panel(fill = c("lightblue", "grey80")) %>%
  add_ridge(color = "snow", variable = "cigarrets") %>%
  add_labels(variable = "cigarrets", nudge_y = 2, 
             text = list(color = "blue", size = 0.5)) %>%
  add_labels(nudge_y = 2, text = list(color = "black", size = 0.5),
             background = list(fill = "white"))



## -----------------------------------------------------------------------------
scplot(exampleA1B1A2B2) %>% 
  set_xaxis(increment = 4, color = "brown") %>%
  set_yaxis(color = "sienna3") %>%
  set_ylabel("Points", color = "sienna3", angle = 0) %>%
  set_xlabel("Weeks", size = 1, color = "brown") %>%
  add_title("Points by week", color = "sienna4", face = 3) %>%
  add_caption("Note: An extensive Example.",
              color = "black", size = 1, face = 3) %>%
  set_phasenames(c("Baseline", "Intervention", "Fall-Back", "Intervention_2"), 
                 size = 0) %>%
  add_ridge(alpha("lightblue", 0.5)) %>%
  set_casenames(labels = sample_names(3), color = "steelblue4", size = 0.7) %>%
  set_panel(fill = c("grey80", "grey95"), color = "sienna4") %>%
  add_grid(color = "grey85", size = 0.5) %>%
  set_dataline(size = 0.5, linetype = "solid", 
               point = list(colour = "sienna4", size = 0.5, shape = 18)) %>%
  add_labels(text = list(color = "sienna", size = 0.7), nudge_y = 4) %>%
  set_separator(size = 0.5, linetype = "solid", color = "sienna") %>%
  add_statline(stat = "trendA", color = "tomato2") %>%
  add_statline(stat = "max", phase = c(1, 3), linetype = "dashed") %>%
  add_marks(case = 1:2, positions = 14, color = "red3", size = 2, shape = 4) %>%
  add_marks(case = "all", positions = "values < quantile(values, 0.1)", 
            color = "blue3", size = 1.5) %>%
  add_marks(positions = outlier(exampleABAB), color = "brown", size = 2) %>%
  add_text(case = 1, x = 5, y = 35, label = "Interesting", 
           color = "darkgreen", angle = 20, size = 0.7) %>%
  add_arrow(case = 1, 5, 30, 5, 22, color = "steelblue") %>%
  set_background(fill = "white") %>%
  add_legend()


